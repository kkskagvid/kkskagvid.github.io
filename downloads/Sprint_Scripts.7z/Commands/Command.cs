using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Commands
{
	public class Command : MonoBehaviour
	{
		private static GameObject initiator;

		public static void CommandInput(string args)
		{
			if (args == "")
				return;

			string[] splits = args.Split(' ');
			int lenght = args.Length;
			string header = splits[0];

			initiator = GameObject.Find("Player");

			if (IsTp(header))
			{
				TpCommand(splits, lenght);
			}
		}

		private static bool IsTp(string s)
		{
			if (s == "/tp")
				return true;

			return false;
		}


		private static void TpCommand(string[] args, int lenght)
		{
			if (lenght < 4)
				return;

			float x, y, z;
			x = float.Parse(args[1]);
			y = float.Parse(args[2]);
			z = float.Parse(args[3]);

			initiator.transform.position = new Vector3(x, y, z);
		}

		public static GameObject Initiator
		{
			get { return initiator; }
			set { initiator = value; }
		}
	}
}
