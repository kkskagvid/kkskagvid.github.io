using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Sprint.Commands;

namespace Sprint.UI
{
	public class UIEvent : MonoBehaviour
	{
		private Button gameSettingsButton;
		private InputField chatBoxInputField;

		private bool showChatbox = false;

		void Start()
		{
			gameSettingsButton = GameObject.Find("UI/GamePanel/GameSettingsButton").GetComponent<Button>();
			chatBoxInputField = GameObject.Find("UI/ChatBar").GetComponent<InputField>();

			chatBoxInputField.gameObject.SetActive(false);

			GameSettingsButtonEvent();
		}

		void Update()
		{
			ChatBarInputFieldEvent();
		}

		#region Event

		private void GameSettingsButtonEvent()
		{
			gameSettingsButton.onClick.AddListener(() =>
			{

			});
		}

		private void ChatBarInputFieldEvent()
		{
			if (Input.GetKeyDown(KeyCode.T))
			{
				showChatbox = true;
			}

			if (showChatbox == true)
			{
				chatBoxInputField.gameObject.SetActive(true);
			}
			else
			{
				chatBoxInputField.gameObject.SetActive(false);
				showChatbox = false;
			}

			if (!chatBoxInputField.IsActive())
			{
				return;
			}

			chatBoxInputField.ActivateInputField();

			// KeyCode.Return = Enter
			if (Input.GetKeyDown(KeyCode.Return))
			{
				string text = chatBoxInputField.text;
				chatBoxInputField.text = string.Empty;

				Command.CommandInput(text);
				showChatbox = false;
			}
		}

		#endregion

	}
}
