using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HpTextUpdate : MonoBehaviour
{
    private Text hpText;
    private Slider hpSlider;

    void Start()
    {
        hpSlider = GetComponent<Slider>();
        hpText = GetComponentInChildren<Text>();
    }

    void Update()
    {
        hpText.text = hpSlider.maxValue + "/" + hpSlider.value;
    }
}
