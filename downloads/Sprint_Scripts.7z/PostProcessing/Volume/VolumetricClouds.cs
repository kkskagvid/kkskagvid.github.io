using System;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Sprint.PostProcessing.Volume
{
	[Serializable, VolumeComponentMenuForRenderPipeline("My-Post-processing/VolumetricClouds", typeof(UniversalRenderPipeline))]
	public class VolumetricClouds : VolumeComponent, IPostProcessComponent
	{
		[Tooltip("Enable Effect")]
		public BoolParameter enableEffect = new BoolParameter(false);

		[Space]
		[Tooltip("Clound Height")]
		public IntParameter cloundHeight = new IntParameter(600);

		[Tooltip("Clound Scale Y")]
		public FloatParameter cloundScaleY = new FloatParameter(450f);


		[Space]
		[Tooltip("Num Steps")]
		public FloatParameter numSteps = new FloatParameter(1f);

		[Tooltip("Absorption")]
		public FloatParameter absorption = new FloatParameter(1f);


		[Space]
		[Tooltip("Base Color")]
		public ColorParameter baseColor = new ColorParameter(Color.white);

		[Tooltip("Num Steps Light")]
		public FloatParameter numStepsLight = new FloatParameter(1f);

		[Tooltip("Light Absorption")]
		public FloatParameter lightAbsorption = new FloatParameter(1f);


		[Space]
		[Tooltip("Main Density Noise Texture")]
		public Texture3DParameter mainDensityNoiseTex = new Texture3DParameter(null);

		[Tooltip("Eroad Noise Texture")]
		public Texture3DParameter eroadNoiseTex = new Texture3DParameter(null);


		[Space]
		[Tooltip("Density Noise Scale")]
		public FloatParameter densityNoiseScale = new FloatParameter(0f);

		[Tooltip("Density Noise Offset")]
		public Vector3Parameter densityNoiseOffset = new Vector3Parameter(Vector3.zero);

		[Tooltip("Density Threshold")]
		public FloatParameter densityThreshold = new FloatParameter(0f);

		[Tooltip("Density Multiplier")]
		public FloatParameter densityMultiplier = new FloatParameter(1f);


		[Space]
		[Tooltip("Erode Density Multiplier")]
		public FloatParameter erodeDensityMultiplier = new FloatParameter(1f);


		[Space]
		[Tooltip("Edge Threshold")]
		public Vector2Parameter edgeThreshold = new Vector2Parameter(Vector2.zero);

		[Space]
		[Tooltip("Phase 1")]
		public FloatParameter phaseG1 = new FloatParameter(0f);
		[Tooltip("Phase 2")]
		public FloatParameter phaseG2 = new FloatParameter(0f);


		public bool IsActive() => enableEffect.value;

		public bool IsTileCompatible() => false;
	}
}
