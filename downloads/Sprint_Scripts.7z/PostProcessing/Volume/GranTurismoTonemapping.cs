using System;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Sprint.PostProcessing.Volume
{

	[Serializable, VolumeComponentMenuForRenderPipeline("My-Post-processing/GranTurismoTonemapping", typeof(UniversalRenderPipeline))]
	public class GranTurismoTonemapping : VolumeComponent, IPostProcessComponent
	{
		[Tooltip("")]
		public BoolParameter enableEffect = new BoolParameter(false);

		[Range(1, 100), Tooltip("Maximum brightness")]
		public FloatParameter P = new FloatParameter(1);

		[Range(0, 5), Tooltip("Contrast")]
		public FloatParameter a = new FloatParameter(1);

		[Range(0, 1), Tooltip("Linear section start")]
		public FloatParameter m = new FloatParameter(0.22f);

		[Range(0, 1), Tooltip("Linear section length")]
		public FloatParameter l = new FloatParameter(0.4f);

		[Range(1, 3), Tooltip("Black tightness")]
		public FloatParameter c = new FloatParameter(1.33f);

		[Range(0, 1), Tooltip("Black tightness")]
		public FloatParameter b = new FloatParameter(0f);

		public bool IsActive() => enableEffect.value;

		public bool IsTileCompatible() => false;

	}
}

