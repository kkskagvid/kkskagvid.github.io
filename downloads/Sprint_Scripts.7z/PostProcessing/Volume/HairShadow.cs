using System;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Sprint.PostProcessing.Volume
{
	[Serializable, VolumeComponentMenuForRenderPipeline("My-Post-processing/HairShadow", typeof(UniversalRenderPipeline))]
	public class HairShadow : VolumeComponent, IPostProcessComponent
	{
		[Tooltip("")]
		public BoolParameter enableEffect = new BoolParameter(false);

		public bool IsActive() => enableEffect.value;

		public bool IsTileCompatible() => false;
	}
}
