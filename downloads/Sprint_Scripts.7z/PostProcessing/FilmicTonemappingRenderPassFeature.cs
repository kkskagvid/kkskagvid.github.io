using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

using Sprint.PostProcessing.Volume;

namespace Sprint.PostProcessing
{
	public class FilmicTonemappingRenderPassFeature : ScriptableRendererFeature
	{
		class FilmicTonemappingRenderPass : ScriptableRenderPass
		{
			public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
			{
			}

			public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
			{
			}

			public override void OnCameraCleanup(CommandBuffer cmd)
			{
			}
		}

		FilmicTonemappingRenderPass renderPass;

		public override void Create()
		{
			this.renderPass = new FilmicTonemappingRenderPass();
		}

		public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
		{
			renderer.EnqueuePass(renderPass);
		}
	}
}
