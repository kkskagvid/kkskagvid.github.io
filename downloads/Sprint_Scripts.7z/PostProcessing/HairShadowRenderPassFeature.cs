using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

using Sprint.PostProcessing.Volume;

public class HairShadowRenderPassFeature : ScriptableRendererFeature
{
	class HairShadowRenderPass : ScriptableRenderPass
	{
		private Material material;

		public HairShadowRenderPass(HairShadowRenderPassFeature.Settings settings, Material material)
		{
			this.material = material;
			this.renderPassEvent = settings.renderPassEvent;
		}

		public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
		{

		}

		public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
		{

		}
	}

	private HairShadowRenderPass renderPass;

	[System.Serializable]
	public class Settings
	{
		public Material material;
		public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRenderingOpaques;
	}
	
	public Settings settings = new Settings();

	public override void Create()
	{
		Material material = settings.material;
		if (material == null)
		{
			Debug.LogError("Materal is null!");
		}

		this.name = "Hair Shadow (Stencil)";
		this.renderPass = new HairShadowRenderPass(settings, material);
	}

	public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
	{
		renderer.EnqueuePass(renderPass);
	}
}
