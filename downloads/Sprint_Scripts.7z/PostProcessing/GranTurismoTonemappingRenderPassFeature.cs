using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

using Sprint.PostProcessing.Volume;

namespace Sprint.PostProcessing
{
	public class GranTurismoTonemappingRenderPassFeature : ScriptableRendererFeature
	{
		class GranTurismoTonemappingRenderPass : ScriptableRenderPass
		{
			private static readonly string renderTag = "Gran Turismo Tonemapping";
			private GranTurismoTonemapping volume;
			private Material material;

			public GranTurismoTonemappingRenderPass(RenderPassEvent renderPassEvent, Material material)
			{
				this.renderPassEvent = renderPassEvent;
				this.material = material;
			}

			public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
			{
				if (!renderingData.cameraData.postProcessEnabled)
				{
					return;
				}

				var stack = VolumeManager.instance.stack;
				volume = stack.GetComponent<GranTurismoTonemapping>();
				if (volume == null)
				{
					Debug.LogError("Get volume error!");
					return;
				}

				var cmd = CommandBufferPool.Get(renderTag);
				Render(cmd, ref renderingData);
				context.ExecuteCommandBuffer(cmd);
				CommandBufferPool.Release(cmd);
			}

			private void Render(CommandBuffer cmd, ref RenderingData renderingData)
			{
				if (!volume.IsActive())
				{
					return;
				}

				RenderTargetIdentifier source = renderingData.cameraData.renderer.cameraColorTarget;
				RenderTextureDescriptor descriptor = renderingData.cameraData.cameraTargetDescriptor;

				var camera = renderingData.cameraData.camera;

				material.SetFloat("_P", volume.P.value);
				material.SetFloat("_A", volume.a.value);
				material.SetFloat("_M", volume.m.value);
				material.SetFloat("_L", volume.l.value);
				material.SetFloat("_C", volume.c.value);
				material.SetFloat("_B", volume.b.value);

				int dest = Shader.PropertyToID("Temp1");

				cmd.GetTemporaryRT(dest, descriptor.width, descriptor.height, 0, FilterMode.Bilinear, RenderTextureFormat.DefaultHDR);
				cmd.Blit(source, dest);
				cmd.Blit(dest, source, material);
			}
		}
		private GranTurismoTonemappingRenderPass renderPass;

		public Settings settings = new Settings();

		[System.Serializable]
		public class Settings
		{
			public Shader shader;
			public RenderPassEvent renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
		}

		public override void Create()
		{
			Material material = CoreUtils.CreateEngineMaterial(settings.shader.name);
			if (material == null)
			{
				Debug.LogError("Create materal error!");
			}

			this.name = "GranTurismoTonemapping";
			this.renderPass = new GranTurismoTonemappingRenderPass(settings.renderPassEvent, material);
		}

		public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
		{
			renderer.EnqueuePass(renderPass);
		}
	}
}
