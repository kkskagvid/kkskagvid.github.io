using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

using Sprint.PostProcessing.Volume;

namespace Sprint.PostProcessing
{
	public class VolumetricCloudsRenderPassFeature : ScriptableRendererFeature
	{
		class VolumetricCloudsRenderPass : ScriptableRenderPass
		{
			private static readonly string renderTag = "Volumetric Cloud";
			private Material material;
			private Settings settings;
			private RenderTargetHandle tempRT;
			private VolumetricClouds volume;
			private GameObject container;

			public VolumetricCloudsRenderPass(Settings settings, Material material)
			{
				this.settings = settings;
				this.renderPassEvent = settings.renderPassEvent;
				this.material = material;
				container = GameObject.Find("Clound");
			}

			public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
			{
				if (!renderingData.cameraData.postProcessEnabled)
				{
					return;
				}

				var stack = VolumeManager.instance.stack;
				volume = stack.GetComponent<VolumetricClouds>();
				if (volume == null)
				{
					Debug.LogError("Get volume error!");
					return;
				}

				var cmd = CommandBufferPool.Get(renderTag);
				Render(cmd, ref renderingData);
				context.ExecuteCommandBuffer(cmd);
				CommandBufferPool.Release(cmd);
			}

			private void Render(CommandBuffer cmd, ref RenderingData renderingData)
			{
				if (!volume.IsActive())
				{
					return;
				}

				var xScale = 4500 / 2;
				var yScale = volume.cloundScaleY.value / 2;
				Vector3 newScale = new Vector3(xScale, yScale, xScale);

				var pos = Camera.main.transform.position;
				Vector3 cloudPosition = new Vector3(pos.x, volume.cloundHeight.value, pos.z);

				material.SetVector("_BoundsMin", cloudPosition - newScale);
				material.SetVector("_BoundsMax", cloudPosition + newScale);

				material.SetFloat("_NumSteps", volume.numSteps.value);
				material.SetFloat("_Absorption", volume.absorption.value);

				material.SetColor("_BaseColor", volume.baseColor.value);
				material.SetFloat("_NumStepsLight", volume.numStepsLight.value);
				material.SetFloat("_LightAbsorption", volume.lightAbsorption.value);

				material.SetTexture("_MainDensityNoiseTex", volume.mainDensityNoiseTex.value);
				material.SetTexture("_ErodeDensityNoiseTex", volume.eroadNoiseTex.value);

				material.SetFloat("_DensityNoiseScale", volume.densityNoiseScale.value);
				material.SetVector("_DensityNoiseOffset", volume.densityNoiseOffset.value);
				material.SetFloat("_DensityThreshold", volume.densityThreshold.value);
				material.SetFloat("_DensityMultiplier", volume.densityMultiplier.value);

				material.SetFloat("_ErodeDensityMultiplier", volume.erodeDensityMultiplier.value);

				material.SetVector("_EdgeThreshold", volume.edgeThreshold.value);

				material.SetFloat("_PhaseG1", volume.phaseG1.value);
				material.SetFloat("_PhaseG2", volume.phaseG2.value);

				RenderTargetIdentifier source = renderingData.cameraData.renderer.cameraColorTarget;
				RenderTextureDescriptor descriptor = renderingData.cameraData.cameraTargetDescriptor;

				var camera = renderingData.cameraData.camera;

				cmd.GetTemporaryRT(tempRT.id, descriptor);
				cmd.Blit(source, tempRT.Identifier(), material);
				cmd.Blit(tempRT.Identifier(), source);
			}
		}

		private VolumetricCloudsRenderPass renderPass;

		[System.Serializable]
		public class Settings
		{
			public Shader shader;
			public RenderPassEvent renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
		}

		public Settings settings = new Settings();

		public override void Create()
		{
			Material material = CoreUtils.CreateEngineMaterial(settings.shader.name);
			if (material == null)
			{
				Debug.LogError("Create materal error!");
			}

			this.name = "VolumetricClouds";
			this.renderPass = new VolumetricCloudsRenderPass(settings, material);
		}

		public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
		{
			renderer.EnqueuePass(renderPass);
		}
	}
}
