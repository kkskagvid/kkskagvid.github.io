using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Animation
{
	public class AnimationManager : MonoBehaviour
	{
		private Animator animator;
		private Transform player;

		private static bool isIdle = true;
		private static bool isWalk = false;
		private static bool isRunning = false;

		void Start()
		{
			animator = GetComponent<Animator>();
			player = GetComponentInParent<Transform>();
		}

		void Update()
		{
			if (Input.GetKeyDown(KeyCode.W) ||
				Input.GetKeyDown(KeyCode.S) ||
				Input.GetKeyDown(KeyCode.A) ||
				Input.GetKeyDown(KeyCode.D)
			)
			{
				isIdle = false;
				isWalk = true;
			}
			else if (Input.GetKeyUp(KeyCode.W) ||
					 Input.GetKeyUp(KeyCode.S) ||
					 Input.GetKeyUp(KeyCode.A) ||
					 Input.GetKeyUp(KeyCode.D)
			)
			{
				isIdle = true;
				isWalk = false;
			}

			animator.SetBool("IsIdle", isIdle);
			animator.SetBool("IsWalk", isWalk);
		}

		public static bool IsIdle
		{
			get { return isIdle; }
		}
	}
}
