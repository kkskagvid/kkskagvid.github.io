using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.CustomPhysics
{
	public class SoftBody : MonoBehaviour
	{
		public Transform breastsL;
		public Transform breastsR;
		public float hardness;

		void Start()
		{

		}

		void FixedUpdate()
		{

		}

	}
}
