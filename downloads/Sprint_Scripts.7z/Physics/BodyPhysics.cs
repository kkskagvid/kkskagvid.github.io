using UnityEngine;

namespace Sprint.CustomPhysics
{
	public class BodyPhysics : MonoBehaviour
	{

	}
}
