using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Util
{
	public class DayNightCycleController : MonoBehaviour
	{
		public bool start = false;
		public float speed;
		public GameObject parent;

		void Update()
		{
			if (!start) return;

			var rotation = Time.deltaTime * speed;
			parent.transform.Rotate(Vector3.right, rotation);
		}
	}
}
