using System.Runtime.InteropServices;

namespace Sprint.Util
{
	public class TargetSystemApi
	{
		public TargetSystemApi() { }

		[DllImport("user32.dll")]
		public static extern int SetCursorPos(int x, int y);
	}
}