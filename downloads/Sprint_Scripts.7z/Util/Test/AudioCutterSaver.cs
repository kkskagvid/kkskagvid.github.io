using System;
using System.IO;
using UnityEngine;

public class AudioCutterSaver : MonoBehaviour
{
	public AudioClip audioClip; // Ҫ�и��ԭʼ��Ƶ����
	public string savePath = "/Resources/Sounds/YAMAHA_Grand_Piano/save"; // ����·������ȷ�����·���ǿ�д��

	private void Start()
	{
		if (audioClip != null)
		{
			int segmentCount = (int)Mathf.Ceil(audioClip.length / 2); // ������Ҫ�и�Ķ���
			for (int i = 0; i < segmentCount; i++)
			{
				float startTime = i * 2.0f;
				float duration = Mathf.Min(2.0f, audioClip.length - startTime);
				AudioClip cutClip = CutAudioClip(audioClip, startTime, duration);
				string filePath = Path.Combine(Application.dataPath + savePath, $"clip_{i + 1}.wav");
				SaveAudioClipToWav(cutClip, filePath);
			}
		}
	}

	AudioClip CutAudioClip(AudioClip originalClip, float startTime, float duration)
	{
		int startSample = (int)(startTime * originalClip.frequency);
		int endSample = (int)((startTime + duration) * originalClip.frequency);

		AudioClip clip = AudioClip.Create("tempClip", endSample - startSample, originalClip.channels, originalClip.frequency, false);
		float[] samples = new float[endSample - startSample];
		originalClip.GetData(samples, startSample);

		clip.SetData(samples, 0);
		return clip;
	}

	void SaveAudioClipToWav(AudioClip clip, string filePath)
	{
		var samples = new float[clip.samples];
		clip.GetData(samples, 0);
		var byteArray = new byte[samples.Length * 2]; // 2 bytes per sample (16-bit)
		var rescaleFactor = 32767; // To convert float to Int16

		for (var i = 0; i < samples.Length; i++)
		{
			var intData = (short)(samples[i] * rescaleFactor);
			var byteArr = BitConverter.GetBytes(intData);
			byteArray[i * 2] = byteArr[0];
			byteArray[(i * 2) + 1] = byteArr[1];
		}

		// Write WAV file
		using (var fileStream = new FileStream(filePath, FileMode.Create))
		{
			using (var writer = new BinaryWriter(fileStream))
			{
				// RIFF header
				writer.Write("RIFF".ToCharArray());
				writer.Write((int)(byteArray.Length + 36)); // Total file length
				writer.Write("WAVE".ToCharArray());

				// Format chunk
				writer.Write("fmt ".ToCharArray());
				writer.Write((int)16); // Length of format data
				writer.Write((short)1); // PCM (uncompressed)
				writer.Write((short)clip.channels); // Number of channels
				writer.Write((int)clip.frequency); // Sample rate
				writer.Write((int)(clip.frequency * clip.channels * 2)); // Byte rate
				writer.Write((short)(clip.channels * 2)); // Block align
				writer.Write((short)16); // Bits per sample

				// Data chunk
				writer.Write("data".ToCharArray());
				writer.Write(byteArray.Length); // Data size
				writer.Write(byteArray); // Audio data
			}
		}
	}
}