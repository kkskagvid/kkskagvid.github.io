using System;
using System.IO;
using UnityEngine;

namespace Sprint.Util
{
	public class GameSettings
	{
		public struct Settings
		{
			public bool cameraAsisXInvert;
			public bool cameraAsisYInvert;
		}

		private static Settings settings = new Settings()
		{
			cameraAsisXInvert = false,
			cameraAsisYInvert = true,
		};

		public static void Load()
		{
			Settings jsonObject = new Settings();

			StreamReader sr = new StreamReader(Application.persistentDataPath + "/GameSettings.json");
			try
			{
				string json = sr.ReadToEnd();
				jsonObject = JsonManager.Deserialize<Settings>(json);
				settings = jsonObject;
				sr.Close();
			}
			catch (IOException e)
			{
				sr.Close();
				throw new Exception(e.Message);
			}
		}

		public static void Save()
		{
			string json = JsonManager.Serialize<Settings>(settings);

			StreamWriter sw = new StreamWriter(Application.persistentDataPath + "/GameSettings.json");
			try
			{
				sw.Write(json);
				sw.Close();
			}
			catch (IOException e)
			{
				sw.Close();
				throw new Exception(e.Message);
			}
		}

		#region Accessor

		public static bool CameraAsisXInvert
		{
			get { return settings.cameraAsisXInvert; }
			set { settings.cameraAsisXInvert = value; }
		}

		public static bool CameraAsisYInvert
		{
			get { return settings.cameraAsisYInvert; }
			set { settings.cameraAsisYInvert = value; }
		}

		#endregion
	}
}
