using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sprint.Player.CameraController;

namespace Sprint.MiniMap
{
	public class MiniMapFollow : CameraController2D
	{

	}
}
