using UnityEngine.UI;
using UnityEngine;

namespace Sprint.MiniMap
{
	public class SimpleTextureMinimap : MaskableGraphic
	{
		public Texture MinimapTexture;
		public Vector2 Pivot = new Vector2(.5f, .5f);

		public float MinimapAreaSize = 50;
		public float DisplayAreaSize = 10;
		public float ImageSize = 100;

		public Transform FollowTarget;

		private void Update()
		{
			if (FollowTarget != null)
				SetVerticesDirty();
		}

		public override Texture mainTexture => MinimapTexture;

		protected override void OnPopulateMesh(VertexHelper vh)
		{
			vh.Clear();

			var radius = ImageSize / 2;
			var uvRadius = DisplayAreaSize / MinimapAreaSize / 2;
			var uvOffset = new Vector2();

			if (FollowTarget != null)
				uvOffset = new Vector2(FollowTarget.position.x, FollowTarget.position.z) / MinimapAreaSize;

			vh.AddVert(new Vector3(-radius, -radius), color, Pivot + uvOffset + new Vector2(-uvRadius, -uvRadius));
			vh.AddVert(new Vector3(-radius, radius), color, Pivot + uvOffset + new Vector2(-uvRadius, uvRadius));
			vh.AddVert(new Vector3(radius, radius), color, Pivot + uvOffset + new Vector2(uvRadius, uvRadius));
			vh.AddVert(new Vector3(radius, -radius), color, Pivot + uvOffset + new Vector2(uvRadius, -uvRadius));

			vh.AddTriangle(0, 1, 2);
			vh.AddTriangle(0, 2, 3);
		}
	}
}
