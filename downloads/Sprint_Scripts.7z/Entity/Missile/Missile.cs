using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Entity.Missiles
{
	public class Missile : MonoBehaviour
	{
		private static GameObject target;

		public static GameObject Target
		{
			get { return target; }
			set { target = value; }
		}
	}
}
