using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace Sprint.Entity.Missiles
{
	public class AIM120DMissile : Missile
	{

	}
}
