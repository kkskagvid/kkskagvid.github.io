using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Player.Ship
{
	public class AircraftCarrierController : ShipController
	{

	}
}

