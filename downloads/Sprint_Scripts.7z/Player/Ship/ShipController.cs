using UnityEngine;

namespace Sprint.Player.Ship
{
	public class ShipController : MonoBehaviour
	{
		protected enum SpeedLevel
		{
			None = 0,

			FULL_AHEAD,
			HALF_AHEAD,
			SLOW_AHEAD,
			DEAD_SLOW_AHEAD,

			STOP,

			DEAD_SLOW_ASTERN,
			SLOW_ASTERN,
			HALF_ASTERN,
			FULL_ASTERN,

			Max,
		}
		private SpeedLevel speedLevel = SpeedLevel.STOP;

		private Rigidbody rb;

		public float[] aheadSpeed = new float[4] { 540f, 320f, 240f, 120f };
		public float[] asternSpeed = new float[4] { 310f, 260f, 110f, 70f };

		void Start()
		{
			rb = GetComponent<Rigidbody>();

			if (rb == null)
			{
				Debug.LogError("Rigidbody is null!");
			}
		}

		void Update()
		{
			GearShift();
			LimitSpeedLevel();
			Movement();
		}

		private void GearShift()
		{
			if (Input.GetKeyDown(KeyCode.W))
			{
				speedLevel -= 1;
			}
			else if (Input.GetKeyDown(KeyCode.S))
			{
				speedLevel += 1;
			}
		}

		private void LimitSpeedLevel()
		{
			if (speedLevel == SpeedLevel.None)
			{
				speedLevel = SpeedLevel.FULL_AHEAD;
			}
			else if (speedLevel == SpeedLevel.Max)
			{
				speedLevel = SpeedLevel.FULL_ASTERN;
			}
		}

		private void Movement()
		{
			switch (speedLevel)
			{
				case SpeedLevel.FULL_AHEAD:
					rb.velocity = new Vector3(0, 0, Vector3.forward.z + Time.deltaTime * aheadSpeed[0]);
					break;
				case SpeedLevel.HALF_AHEAD:
					rb.velocity = new Vector3(0, 0, Vector3.forward.z + Time.deltaTime * aheadSpeed[1]);
					break;
				case SpeedLevel.SLOW_AHEAD:
					rb.velocity = new Vector3(0, 0, Vector3.forward.z + Time.deltaTime * aheadSpeed[2]);
					break;
				case SpeedLevel.DEAD_SLOW_AHEAD:
					rb.velocity = new Vector3(0, 0, Vector3.forward.z + Time.deltaTime * aheadSpeed[3]);
					break;

				// =============================================================================================================

				case SpeedLevel.DEAD_SLOW_ASTERN:
					rb.velocity = new Vector3(0, 0, -Mathf.Abs(Vector3.forward.z + Time.deltaTime * asternSpeed[3]));
					break;
				case SpeedLevel.SLOW_ASTERN:
					rb.velocity = new Vector3(0, 0, -Mathf.Abs(Vector3.forward.z + Time.deltaTime * asternSpeed[2]));
					break;
				case SpeedLevel.HALF_ASTERN:
					rb.velocity = new Vector3(0, 0, -Mathf.Abs(Vector3.forward.z + Time.deltaTime * asternSpeed[1]));
					break;
				case SpeedLevel.FULL_ASTERN:
					rb.velocity = new Vector3(0, 0, -Mathf.Abs(Vector3.forward.z + Time.deltaTime * asternSpeed[0]));
					break;

				case SpeedLevel.STOP:
				default:
					rb.velocity = Vector3.zero;
					break;
			}
		}
	}
}
