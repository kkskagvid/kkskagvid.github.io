using System;

namespace Sprint.Player.Human
{
	public enum PlayerState
	{
		None = 0,

		Idle,
		Walk,
		Run,
		Stop,
		Jump,
		Fly,

		Survival,
		Death,
		Rebirth,
	}

}
