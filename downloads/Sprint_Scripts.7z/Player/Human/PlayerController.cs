using UnityEngine;

namespace Sprint.Player.Human
{
	public class PlayerController : MonoBehaviour
	{
		public float speed = 7f;
		public float addForce = 3f;
		public float jumpForce = 0.75f;

		public float decelerationRate = 5f;
		public float rotationSpeed = 10f;

		private Rigidbody rb;
		private UnityEngine.Camera mainCamera;
		private Transform playerTransform;
		private bool isJumping = false;

		void Start()
		{
			rb = GetComponent<Rigidbody>();

			playerTransform = transform;
			mainCamera = UnityEngine.Camera.main;
		}

		void Update()
		{
			Movement();
		}

		void FixedUpdate()
		{
			if (isJumping)
			{
				rb.AddForce((new Vector3(0f, 2f, 0f) * jumpForce).normalized, ForceMode.Impulse);
				isJumping = false;
			}
		}

		private void Movement()
		{
			var dir = Vector3.zero;

			if (mainCamera == null)
			{
				Debug.LogError("Main camera not found.");
				return;
			}

			if (Input.GetKey(KeyCode.W))
			{
				dir += mainCamera.transform.TransformDirection(Vector3.forward);
			}
			if (Input.GetKey(KeyCode.S))
			{
				dir -= mainCamera.transform.TransformDirection(Vector3.forward);
			}
			if (Input.GetKey(KeyCode.A))
			{
				dir -= mainCamera.transform.TransformDirection(Vector3.right);
			}
			if (Input.GetKey(KeyCode.D))
			{
				dir += mainCamera.transform.TransformDirection(Vector3.right);
			}

			if (Input.GetKey(KeyCode.LeftShift))
			{
				dir *= addForce;
			}

			if (Input.GetButton("Jump"))
			{
				isJumping = true;
			}

			// Restrict movement to the horizontal plane only
			dir.y = 0f; // Clear the y component
			dir.Normalize();

			// If there is directional input, apply acceleration
			if (dir != Vector3.zero)
			{
				rb.velocity = dir * speed;

				// Make the player face the direction of movement
				Quaternion targetRotation = Quaternion.LookRotation(dir, Vector3.up);
				playerTransform.rotation = Quaternion.Lerp(playerTransform.rotation, targetRotation, Time.deltaTime * rotationSpeed);
			}
			else
			{
				// If there is no directional input, decelerate linearly
				rb.velocity = Vector3.Lerp(rb.velocity, Vector3.zero, Time.deltaTime * decelerationRate);
			}
		}
	}
}
