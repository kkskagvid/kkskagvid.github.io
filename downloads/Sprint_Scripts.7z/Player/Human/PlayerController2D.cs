using UnityEngine;

public class PlayerController2D : MonoBehaviour
{
	public float speed = 10f;

	private Rigidbody2D rb2D;

	void Start()
	{
		rb2D = GetComponent<Rigidbody2D>();

		Cursor.lockState = CursorLockMode.Locked;
	}

	void Update()
	{
		Movement();
	}

	private void Movement()
	{
		var horizontal = Input.GetAxisRaw("Horizontal");
		var vertical = Input.GetAxisRaw("Vertical");

		var dir = Vector3.zero;
		dir = new Vector3(horizontal, vertical, 0);


		Facing(horizontal);

		rb2D.velocity = speed * 5 * Time.deltaTime * dir.normalized;
	}

	private void Facing(float horizontal)
	{
		if (horizontal < 0)
		{
			transform.localRotation = Quaternion.Euler(0f, -90f, 0f);
		}
		else if (horizontal > 0)
		{
			transform.localRotation = Quaternion.Euler(0f, 90f, 0f);
		}
		else
		{
			if (transform.localRotation.eulerAngles.y == 270f)
			{
				transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
			}
			else if (transform.localRotation.eulerAngles.y == 90f)
			{
				transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
			}
		}
	}
}
