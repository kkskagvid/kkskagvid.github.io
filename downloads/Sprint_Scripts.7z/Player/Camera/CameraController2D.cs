using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Sprint.Player.CameraController
{
	public class CameraController2D : MonoBehaviour
	{
		public float followSmoothTime = 0.7f;

		public Transform target;
		private Vector3 offset;
		private Vector3 velocity;

		void Start()
		{
			offset = transform.position - target.position;
		}

		void LateUpdate()
		{
			Vector3 targetPosition = target.position + offset;
			Vector3 smoothPosition = Vector3.SmoothDamp(
				  transform.position,
				  targetPosition,
				  ref velocity,
				  followSmoothTime
			);

			transform.position = smoothPosition;
		}
	}
}
